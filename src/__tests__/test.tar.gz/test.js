const {writeHeapSnapshot} = require('node:v8')
const {
  Worker,
  isMainThread,
  parentPort
} = require('node:worker_threads')

if (isMainThread) {
  const worker = new Worker(__filename)

  worker.once('message', (filename) => {
    console.log(`worker heapdump: ${filename}`)
    // Now get a heapdump for the main thread.
    console.log(`main thread heapdump: ${writeHeapSnapshot()}`)
  })

  // Tell the worker to create a heapdump.
  worker.postMessage('heapdump')
} else {
  parentPort.once('message', (message) => {
    if (message === 'heapdump') {
      // Generate a heapdump for the worker
      // and return the filename to the parent.
      parentPort.postMessage(writeHeapSnapshot())
    }
  })
}

const arr = []
